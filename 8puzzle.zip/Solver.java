/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private int totalMoves;
    private boolean solvable;
    private Search next;

    private class Search implements Comparable<Search> {
        private int moves;
        private Search prev;
        private int priority;
        private Board board;

        public Search(Board b, int m, Search prevNode) {
            board = b;
            moves = m;
            prev = prevNode;
            priority = moves + board.manhattan();
        }

        public int compareTo(Search that) {
            return this.priority - that.priority;
        }

        public boolean isGoal() {
            return board.isGoal();
        }

        public Board getBoard() {
            return board;
        }

        public int getMoves() {
            return moves;
        }

        public int getPriority() {
            return priority;
        }
    }

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial == null) throw new java.lang.IllegalArgumentException("Board is null");
        if (initial.isGoal()) {
            solvable = true;
            next = new Search(initial, 0, null);
            return;
        }
        Board initialTwin = initial.twin();
        MinPQ<Search> pq = new MinPQ<>();
        MinPQ<Search> pqTwin = new MinPQ<>();
        Search node1 = new Search(initial, 0, null);
        pq.insert(node1); // maybe remove this
        pqTwin.insert(new Search(initialTwin, 0, null));
        Search nextTwin;
        do {
            next = pq.delMin();
            nextTwin = pqTwin.delMin();

            for (Board neighbr : next.getBoard().neighbors()) {
                if (next.moves == 0) {
                    pq.insert(new Search(neighbr, next.getMoves() + 1, next));
                }
                else if (next.prev != null && !neighbr.equals(next.prev.getBoard())) {
                    pq.insert(new Search(neighbr, next.getMoves() + 1, next));
                }
            }

            for (Board neighbr : nextTwin.getBoard().neighbors()) {
                if (nextTwin.moves == 0) {
                    pqTwin.insert(new Search(neighbr, nextTwin.getMoves() + 1, nextTwin));
                }
                else if (nextTwin.prev != null && !neighbr.equals(nextTwin.prev.getBoard())) {
                    pqTwin.insert(new Search(neighbr, nextTwin.getMoves() + 1, nextTwin));
                }
            }

        } while (!next.isGoal() && !nextTwin.isGoal());
        if (next.isGoal()) {
            solvable = true;
            totalMoves = next.getMoves();
            return;
        }
        solvable = false;
        // next = nextTwin;
    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return solvable;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable()) return -1;
        return totalMoves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        Stack<Board> solBoards = new Stack<>();
        solBoards.push(next.getBoard());
        while (next.prev != null) {
            next = next.prev;
            solBoards.push(next.getBoard());
        }

        return solBoards;
    }

    // test client (see below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
