/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.MinPQ;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;

public class Solver {
    private int totalMoves;
    private boolean solvable;
    private Search next;
    // private boolean alreadySolved;

    private class Search implements Comparable<Search> {
        private int moves;
        private Search prev;
        private int priority;
        private Board board;

        public Search(Board b, int m) {
            board = b;
            this.moves = m;
            priority = moves + board.manhattan();
        }

        public int compareTo(Search that) {
            return Integer.compare(this.priority, that.priority);
        }

        public boolean isGoal() {
            return board.isGoal();
        }

        public Board getBoard() {
            return board;
        }

        public int getMoves() {
            return moves;
        }
    }

    // find a solution to the initial board (using the A* algorithm)
    public Solver(Board initial) {
        if (initial.isGoal()) {
            solvable = true;
            next = new Search(initial, 0);
            return;
        }
        MinPQ<Search> pq = new MinPQ<>();
        Search node1 = new Search(initial, 0);
        node1.prev = null;
        pq.insert(node1);
        // int k = 0;
        next = pq.delMin(); // this here
        do {
            // moves++;
            // StdOut.println("neighbors start");
            // pq = new MinPQ<Search>();
            for (Board neighbr : next.getBoard().neighbors()) {
                // StdOut.println(neighbr);
                if (!neighbr.equals(next.getBoard()))
                    pq.insert(new Search(neighbr, next.getMoves() + 1));
            }
            // StdOut.println("neighbors start");
            node1 = next;
            next = pq.delMin();
            next.prev = node1;
            // k++;
            // StdOut.println(next.getBoard());
        } while (!next.isGoal());
        solvable = true;
        // StdOut.println(k);
        totalMoves = next.getMoves();

    }

    // is the initial board solvable? (see below)
    public boolean isSolvable() {
        return solvable;
    }

    // min number of moves to solve initial board; -1 if unsolvable
    public int moves() {
        if (!isSolvable()) return -1;
        return totalMoves;
    }

    // sequence of boards in a shortest solution; null if unsolvable
    public Iterable<Board> solution() {
        if (!isSolvable()) return null;
        Stack<Board> solBoards = new Stack<>();
        solBoards.push(next.getBoard());
        while (next.prev != null) {
            next = next.prev;
            solBoards.push(next.getBoard());
        }

        return solBoards;
    }

    // test client (see below)
    public static void main(String[] args) {
        // create initial board from file
        In in = new In(args[0]);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                tiles[i][j] = in.readInt();
        Board initial = new Board(tiles);

        // solve the puzzle
        Solver solver = new Solver(initial);

        // print solution to standard output
        if (!solver.isSolvable())
            StdOut.println("No solution possible");
        else {
            StdOut.println("Minimum number of moves = " + solver.moves());
            for (Board board : solver.solution())
                StdOut.println(board);
        }
    }
}
