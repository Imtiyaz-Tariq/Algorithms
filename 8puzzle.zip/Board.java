/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.Stack;
import edu.princeton.cs.algs4.StdOut;
import edu.princeton.cs.algs4.StdRandom;

import java.util.Arrays;

public class Board {
    private int[][] board;
    private int size;
    private int[] blank;
    private int row1;
    private int col1;

    // create a board from an n-by-n array of tiles,
    // where tiles[row][col] = tile at (row, col)
    public Board(int[][] tiles) {
        size = tiles[0].length;
        blank = new int[2]; // blank[0] - row blank[1]- col
        board = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                board[i][j] = tiles[i][j];
                if (board[i][j] == 0) {
                    blank[0] = i;
                    blank[1] = j;
                }
            }
        }
        do {
            row1 = StdRandom.uniformInt(size);
            col1 = StdRandom.uniformInt(size);
        } while (board[row1][col1] == 0);

    }

    // string representation of this board
    public String toString() {
        StringBuilder stringForm = new StringBuilder();
        stringForm.append(dimension() + "\n");
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                stringForm.append(String.format("%2d ", board[i][j]));
            }
            stringForm.append("\n");
        }

        return stringForm.toString();
    }

    // board dimension n
    public int dimension() {
        return size;
    }

    // number of tiles out of place
    public int hamming() {
        int count = 0;
        int x = 1;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (board[i][j] != x++) count++;
            }
        }
        count--; // 0 also included.
        return count;
    }

    // sum of Manhattan distances between tiles and goal
    public int manhattan() {
        int sum = 0;
        int x = 1;
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                if (board[i][j] != x++ && board[i][j] != 0) {
                    double rowDiff = Math.abs(
                            Math.ceil((double) board[i][j] / (double) size) - i - 1);
                    double colDiff = Math.abs(
                            ((board[i][j] % size == 0) ? size : board[i][j] % size) - j - 1);
                    sum += rowDiff + colDiff;
                }
            }
        }
        return sum;
    }

    // is this board the goal board?
    public boolean isGoal() {
        if (hamming() == 0) return true;
        return false;
    }

    // does this board equal y?
    public boolean equals(Object y) {
        if (y == this) return true;
        if (y == null) return false;
        if (this.getClass() != y.getClass()) return false;
        Board that = (Board) y;
        if (!Arrays.deepEquals(this.board, that.board)) return false;
        return true;
    }

    // all neighboring boards
    public Iterable<Board> neighbors() {
        Stack<Board> boardStack = new Stack<>();
        int[][] neighbr = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                neighbr[i][j] = board[i][j];
            }
        }
        if (blank[0] != 0) {
            move(-1, 0, neighbr);
            boardStack.push(new Board(neighbr));
            move(-1, 0, neighbr); // to reverse the last swipe
        }
        if (blank[1] != 0) {
            move(0, -1, neighbr);
            boardStack.push(new Board(neighbr));
            move(0, -1, neighbr); // to reverse the last swipe
        }
        if (blank[0] != size - 1) {
            move(1, 0, neighbr);
            boardStack.push(new Board(neighbr));
            move(1, 0, neighbr); // to reverse the last swipe
        }
        if (blank[1] != size - 1) {
            move(0, 1, neighbr);
            boardStack.push(new Board(neighbr));
            move(0, 1, neighbr); // to reverse the last swipe
        }

        return boardStack;
    }

    // a board that is obtained by exchanging any pair of tiles
    public Board twin() {
        int[][] twin = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                twin[i][j] = board[i][j];
            }
        }
        // ArrayList<Integer> dir = new ArrayList<>();
        // 1 - right, 2 - down, 3 - left, 4 - up
        // if (blank[0] != 0) dir.add(4);
        // if (blank[1] != 0) dir.add(3);
        // if (blank[0] != size - 1) dir.add(2);
        // if (blank[1] != size - 1) dir.add(1);

        // int choice = dir.get(StdRandom.uniformInt(dir.size()));
        // int choice = StdRandom.uniformInt(4);


        while (true) {
            if (row1 != 0 && twin[row1 - 1][col1] != 0) {
                swap(row1, col1, -1, 0, twin);
                break;
            }
            if (col1 != 0 && twin[row1][col1 - 1] != 0) {
                swap(row1, col1, 0, -1, twin);
                break;
            }
            if (row1 != size - 1 && twin[row1 + 1][col1] != 0) {
                swap(row1, col1, 1, 0, twin);
                break;
            }
            if (col1 != size - 1 && twin[row1][col1 + 1] != 0) {
                swap(row1, col1, 0, 1, twin);
                break;
            }
        }

        return new Board(twin);

    }

    private void swap(int row, int col, int rowInc, int colInc, int[][] boardArray) {
        int temp = boardArray[row][col];
        boardArray[row][col] = boardArray[row + rowInc][col + colInc];
        boardArray[row + rowInc][col + colInc] = temp;
    }

    private void move(int row, int col, int[][] boardArray) {
        int temp = boardArray[blank[0] + row][blank[1] + col];
        boardArray[blank[0] + row][blank[1] + col] = boardArray[blank[0]][blank[1]];
        boardArray[blank[0]][blank[1]] = temp;
    }


    // unit testing (not graded)
    public static void main(String[] args) {
        // read in the board specified in the filename
        String file = args[0];
        In in = new In(file);
        int n = in.readInt();
        int[][] tiles = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                tiles[i][j] = in.readInt();
            }
        }

        // solve the slider puzzle
        Board initial = new Board(tiles);
        // StdOut.println(initial.manhattan());
        // StdOut.println("hamming :" + initial.hamming());
        StdOut.println(initial);
        StdOut.println(initial.twin());
        StdOut.println(initial.twin());
        StdOut.println("neighbors: ");
        for (Board b : initial.neighbors()) {
            StdOut.println(b.toString());
        }
    }
}
