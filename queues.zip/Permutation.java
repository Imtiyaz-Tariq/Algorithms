/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.StdIn;
import edu.princeton.cs.algs4.StdOut;

public class Permutation {
    public static void main(String[] args) {
        if (args.length != 1) return;
        RandomizedQueue<String> ranQ = new RandomizedQueue<>();
        int k = Integer.parseInt(args[0]);
        while (!StdIn.isEmpty()) {
            ranQ.enqueue(StdIn.readString());
            k--;
        }
        while (k > 0) {
            StdOut.println(ranQ.dequeue());
            k--;
        }
    }
}
