import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;
import java.util.NoSuchElementException;

public class RandomizedQueue<Item> implements Iterable<Item> {
    private Item[] queue;
    private int items;

    // construct an empty randomized queue
    public RandomizedQueue() {
        queue = (Item[]) new Object[1];
        items = 0;
    }

    // Iterator class
    private class RandomizedQueueIterator implements Iterator<Item> {
        private int[] order;
        private int current = items;

        public RandomizedQueueIterator() {
            order = new int[items];
            for (int i = 0; i < items; i++) {
                order[i] = i;
            }
            StdRandom.shuffle(order);
        }

        public boolean hasNext() {
            return current != 0;
        }

        public Item next() {
            if (!hasNext()) throw new NoSuchElementException();
            return queue[order[--current]];
        }

        public void remove() {
            throw new UnsupportedOperationException();
        }
    }

    // is the randomized queue empty?
    public boolean isEmpty() {
        return items == 0;
    }

    // return the number of items on the randomized queue
    public int size() {
        return items;
    }

    // add the item
    public void enqueue(Item item) {
        if (item == null) throw new IllegalArgumentException();
        if (items >= queue.length) resize(queue.length * 2);
        queue[items++] = item;
    }

    // remove and return a random item
    public Item dequeue() {
        if (isEmpty()) throw new NoSuchElementException();
        if (items <= queue.length / 4) resize(queue.length / 2);
        int ran = StdRandom.uniformInt(0, items);
        Item rem = queue[ran];
        queue[ran] = queue[--items];
        queue[items] = null;
        return rem;
    }

    // return a random item (but do not remove it)
    public Item sample() {
        if (isEmpty()) throw new NoSuchElementException();
        int ran = StdRandom.uniformInt(0, items);
        return (queue[ran]);
    }

    // return an independent iterator over items in random order
    public Iterator<Item> iterator() {
        return new RandomizedQueueIterator();
    }

    // resize an array dynamically
    private void resize(int max) {
        Item[] temp = (Item[]) new Object[max];
        for (int i = 0; i < items; i++) {
            temp[i] = queue[i];
        }
        queue = temp;
    }

    // unit testing (required)
    public static void main(String[] args) {
        RandomizedQueue<Integer> ranQue = new RandomizedQueue<>();
        for (int i = 0; i < 5; i++) {
            ranQue.enqueue(i);
        }

        for (int a : ranQue) {
            System.out.println(" shuffled: " + a);
        }
        while (!ranQue.isEmpty()) {
            System.out.println(ranQue.dequeue());
        }
    }
}
