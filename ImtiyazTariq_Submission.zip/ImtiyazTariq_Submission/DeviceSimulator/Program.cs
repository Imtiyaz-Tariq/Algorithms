﻿using Microsoft.Azure.Devices.Client;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace SensorSimulator
{
    internal class Program
    {
        //Connection string for device to cloud messaging
        private static readonly string connectionString_IoTHubDev1 = ConfigurationManager.AppSettings["connectionString1"];
        private static readonly string connectionString_IoTHubDev2 = ConfigurationManager.AppSettings["connectionString2"];
        private static readonly string connectionString_IoTHubDev3 = ConfigurationManager.AppSettings["connectionString3"];
        //Device Client
        static DeviceClient sensorDevice1Client;
        static DeviceClient sensorDevice2Client;
        static DeviceClient sensorDevice3Client;

        //Random Generator
        static Random random = new Random();

        //truck sensor details
        //const string SensorId = "1";
        const int mpd_Flr = 1;
        static DateTime StreamTime = DateTime.Now;
        static double o3 = 45.5;
        const double o3_min = 0.5;
        const double o3_max = 100.5;
        static double co = 23.43;
        const double co_min = 3.43;
        const double co_max = 103.43;
        const double pm25_min = 0.04;
        const double pm25_max = 950; 
        static double pm25 = 67.6;
        const double no2_min = 0.01;
        const double no2_max = 362; 
        static double no2 = 28.6; 
        const double so2_min = 0.01;
        const double so2_max = 194; 
        static double so2 = 14.5; 
        /*  
         *  Main Method
         */
        static void Main(string[] args)
        {
            var cts = new CancellationTokenSource();
            Console.WriteLine("Press CTRL+C to stop the simulation");
            Console.CancelKeyPress += (s, e) =>
            {
                Console.WriteLine("Stopping the Application....");
                cts.Cancel();
                e.Cancel = true;
            };

            sensorDevice1Client = DeviceClient.CreateFromConnectionString(connectionString_IoTHubDev1);
            sensorDevice2Client = DeviceClient.CreateFromConnectionString(connectionString_IoTHubDev2);
            sensorDevice3Client = DeviceClient.CreateFromConnectionString(connectionString_IoTHubDev3);

            SendMessagesToIoTHub(cts.Token);

            Console.ReadLine();
        }
        /*
         * Sends Messages to IOT Hub
         */
        private static async void SendMessagesToIoTHub(CancellationToken token)
        {
            int SensorId;
            int randomSensorId;
            int[] flrs = { 1, 2, 3 };
            while (!token.IsCancellationRequested)
            {
                SensorId = 101;
                randomSensorId = random.Next(101, 116);
                foreach (int flr in flrs)
                {
                    for (int i = 0; i < 5; i++)
                    {
                        pm25 = GenerateSensorReading(pm25, pm25_min, pm25_max);
                        o3 = GenerateSensorReading(o3, o3_min, o3_max);
                        co = GenerateSensorReading(co, co_min, co_max);
                        no2 = GenerateSensorReading(no2, no2_min, no2_max);
                        so2 = GenerateSensorReading(so2, so2_min, so2_max);
                        

                        var json = CreateJSON(SensorId.ToString(), flr, pm25,o3,co, no2, so2);
                        var message = CreateMessage(json);
                        //Create a random error message
                        if (SensorId == randomSensorId)
                        {
                            SendRandomError(message, randomSensorId);
                            Console.WriteLine($"Error data at {DateTime.Now} and data : {json}");
                            SensorId += 1;
                            continue;
                        }

                        message.Properties.Add("deviceError", "false");

                        if (pm25 > 65 || co > 60 || o3 > 60 || no2 > 60 || so2 > 60)
                            message.Properties.Add("thesholdBreach", "true");
                        else
                            message.Properties.Add("thresholdBreach", "false");
                            

                        if (SensorId < 106)
                        {
                            await sensorDevice1Client.SendEventAsync(message);
                        }
                        else if (SensorId < 111)
                        {
                            await sensorDevice2Client.SendEventAsync(message);
                        }
                        else
                        {
                            await sensorDevice3Client.SendEventAsync(message);
                        }

                        Console.WriteLine($"Sending data at {DateTime.Now} and data : {json} : {message.Properties.Values}");
                        SensorId += 1;
                        
                    }
                   
                }
                await Task.Delay(30000*3);
            }
        }
        /*
         * Creating an erro message with proper floor-sensor mapping
         */
        private static async void SendRandomError(Message message,int randomSensorId)
        {
            message.Properties.Add("deviceError", "true");
            if (randomSensorId > 100 && randomSensorId < 106)
            {
                await sensorDevice1Client.SendEventAsync(message);
                return;
            }
            else if (randomSensorId > 105 && randomSensorId < 111)
            {
                await sensorDevice2Client.SendEventAsync(message);
                return;
            }
            await sensorDevice3Client.SendEventAsync(message);
            
        }

        /*
         * Generate random sensor reading
         */
        private static double GenerateSensorReading(double currentValue, double min, double max)
        {
            double percentage = 5; // 5%

            // generate a new value based on the previous supplied value
            // The new value will be calculated to be within the threshold specified by the "percentage" variable from the original number.
            // The value will also always be within the the specified "min" and "max" values.
            double value = currentValue * (1 + ((percentage / 100) * (2 * random.NextDouble() - 1)));

            value = Math.Max(value, min);
            value = Math.Min(value, max);

            return value;
        }
        /*
         * Create a JSON from an object
         */
        private static string CreateJSON(string sid,int mpdflr,double pollutant1, double pollutant2, double pollutant3, double pollutant4,double pollutant5)
        {
            var data = new
            {
                sensorId = sid,
                mpd_Flr = mpdflr,
                StreamTime = DateTime.Now,
                pm25 = pollutant1,
                o3 = pollutant2,
                co = pollutant3,
                no2 = pollutant2,
                so2 = pollutant3                   

            };
            return JsonConvert.SerializeObject(data);
        }
        /*
         * Build message for IOT HUB
         */
        private static Message CreateMessage(string jsonObject)
        {
            var message = new Message(Encoding.ASCII.GetBytes(jsonObject));
            
            // MESSAGE CONTENT TYPE
            message.ContentType = "application/json";
            message.ContentEncoding = "UTF-8";

            return message;
        }
    }
}
