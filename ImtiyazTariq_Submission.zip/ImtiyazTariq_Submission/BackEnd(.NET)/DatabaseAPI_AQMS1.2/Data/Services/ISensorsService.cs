﻿using DatabaseAPI_AQMS1._2.Models;

namespace DatabaseAPI_AQMS1._2.Data.Services
{
    public interface ISensorsService
    {
        // Commented ones not in  scope of current implementation
        //List<Sensor> GetSensors();
        List<Sensor> GetBySpan(int sec);
        //List<Sensor> GetByFlr(int flr);
        //void Post(Sensor sensor);
    }
}
