﻿using DatabaseAPI_AQMS1._2.Models;
using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.AspNetCore.Mvc;
using DatabaseAPI_AQMS1._2.Controllers;
using Serilog;

namespace DatabaseAPI_AQMS1._2.Data.Services
{
    public class SensorsService : ISensorsService
    {
        // Creating database context variable
        private SensorDbContext _dbContext;
        private readonly ILogger<SensorsController> _logger;

        //Constructor
        public SensorsService(SensorDbContext context, ILogger<SensorsController> logger)
        {
            _dbContext = context;
            _logger = logger;
        }
        // Commented ones not in  scope of current implementation
        //public List<Sensor> GetSensors() => _dbContext.Sensors.ToList();
        public List<Sensor> GetBySpan(int sec)
        {
            List<Sensor> Sensors = null;
            TimeSpan span = TimeSpan.FromSeconds(sec); //FromMinutes(sec);;
            DateTime now = DateTime.Now;
            DateTime spanPastNow = now.Subtract(span);
            // querying records between now and sec seconds pastnow
            try 
            { 
                Sensors = _dbContext.Sensors.Where(a => a.StreamTime > spanPastNow && a.StreamTime < now).ToList();
            }
            catch (Exception ex)
            {
                Log.Error(ex.Message, ex);
            }
            return Sensors;
        }

        // Commented ones not in  scope of current implementation
        /*public List<Sensor> GetByFlr(int flr)
        {
            try
            {
                //querying data for a particular floor
                var Sensors = _dbContext.Sensors.Where(a => a.mpd_Flr == flr).ToList();
                if (Sensors.Count() == 0)
                {
                    return null;
                }
                return Sensors;
            }
            catch (Exception e)
            {
                return null;
                
            }
        }

        public void Post(Sensor sensor)
        {
            try
            {
                sensor.StreamTime = DateTime.Now;
                _dbContext.Sensors.Add(sensor);
                _dbContext.SaveChanges();
            }
            catch (Exception)
            {
                return;
            }
        }*/
    }
}
