import { useState, useEffect, useCallback } from "react";
import AqiMeter from "./AqiMeter";
import DataTable from "./DataTable";
import "./DataTable.css";
import { getAveragePerFloor, getAuthToken} from "./utils";
function Homepage() {
  const [sensorData, setSensorData] = useState([]); // Array to store incoming sensor data
  //const [isLoading, setIsLoading] = useState();
  const [error, setError] = useState(true);
  const token = getAuthToken();

  // Function to handle HTTPS request to fetch sensors data
  const fetchSensorsDataHandler = useCallback(async () => {
    setError(null);
    
    try {
      //const response = await fetch("https://localhost:44309/api/Sensors/GetBySpan?sec=5", {
        //const response = await fetch("https://aqms.azurewebsites.net/api/Sensors/GetBySpan?sec=300", {
        const response = await fetch("https://aqmsbackendapi.azurewebsites.net/api/Sensors/GetBySpan?sec=300", {
        headers: {
          Authorization: "Bearer " + token,
        },
      });
      if (!response.ok) {
        throw new Error("Something went wrong!");
      }
      if (response.status === 204){
        throw new Error("No data to show!");
      }
      const data = await response.json();
      setSensorData(data);
    } catch (error) {
      setError(error.message);
    }
    //setIsLoading(false);
  }, [token]);

  // Making HTTPS request after set iterval
  useEffect(() => {
    setInterval(function () {
      fetchSensorsDataHandler();
    }, 6000);
  }, [fetchSensorsDataHandler]);
  var flrWiseAvg = null;
  if (sensorData != null) {
    flrWiseAvg = getAveragePerFloor(sensorData);
  }

  return (
    <div className="outer_div">

      <div className="center"> Air Quality Management System </div>

      <AqiMeter data1={sensorData} />
      
      {error && <p className="error">{error}</p>}

      <DataTable dt={flrWiseAvg} />

    </div>
  );
}

export default Homepage;