import Livedata from '../Components/Livedata';

function LivedataPage() {
  return (
    <Livedata />
  );
}

export default LivedataPage;