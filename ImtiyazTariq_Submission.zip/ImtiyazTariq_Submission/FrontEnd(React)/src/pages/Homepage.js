import Homepage from '../Components/Homepage';

function homepage() {
  return (
    <Homepage />
  );
}

export default homepage;