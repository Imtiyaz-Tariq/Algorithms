/* *****************************************************************************
 *  Name:
 *  Date:
 *  Description:
 **************************************************************************** */

import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.Queue;
import edu.princeton.cs.algs4.RectHV;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class KdTree {
    private int size;
    private Node root;

    private static class Node {
        private Point2D p;      // the point
        private RectHV rect;    // the axis-aligned rectangle corresponding to this node
        private Node lb;        // the left/bottom subtree
        private Node rt;        // the right/top subtree

        public Node(Point2D p, RectHV rect) {
            this.p = p;
            this.rect = rect;
        }
    }

    // private SET<Point2D> pSet;

    public KdTree() { // construct an empty set of points
        size = 0;
        // root = new Node(null, new RectHV(0, 0, 1, 1));
    }

    public boolean isEmpty() { // is the set empty?
        return size == 0;
    }

    public int size() { // number of points in the set
        return size;
    }

    public void insert(Point2D p) { // add the point to the set (if it is not already in the set)
        if (p == null) throw new IllegalArgumentException();
        root = insertx(root, p, null);

    }

    private Node insertx(Node x, Point2D p, RectHV rect) {
        if (isEmpty()) {
            size++;
            return new Node(p, new RectHV(0, 0, 1, 1));
        }
        if (x == null) {
            size++;
            return new Node(p, rect);
        }

        if (p.x() > x.p.x() || p.x() == x.p.x() && p.y() != x.p.y())
            x.rt = inserty(x.rt, p,
                           new RectHV(x.p.x(), x.rect.ymin(), x.rect.xmax(), x.rect.ymax()));
        else if (p.x() < x.p.x())
            x.lb = inserty(x.lb, p,
                           new RectHV(x.rect.xmin(), x.rect.ymin(), x.p.x(), x.rect.ymax()));
        else {
            x.p = p;
            // size++;
        }
        // size++;
        return x;
    }

    private Node inserty(Node x, Point2D p, RectHV rect) {
        if (x == null) {
            size++;
            return new Node(p, rect);
        }
        if (p.y() > x.p.y() || p.y() == x.p.y() && p.x() != x.p.x())
            x.rt = insertx(x.rt, p,
                           new RectHV(x.rect.xmin(), x.p.y(), x.rect.xmax(), x.rect.ymax()));
        else if (p.y() < x.p.y()) // canged here
            x.lb = insertx(x.lb, p,
                           new RectHV(x.rect.xmin(), x.rect.ymin(), x.rect.xmax(), x.p.y()));
        else {
            x.p = p;
            // size++;
        }
        // size++;
        return x;
    }

    public boolean contains(Point2D p) { // does the set contain point p?
        if (p == null) throw new IllegalArgumentException();
        return containsx(p, root);

    }

    private boolean containsx(Point2D p, Node x) {
        if (x == null) return false;

        if (p.x() > x.p.x() || p.x() == x.p.x() && p.y() != x.p.y()) return containsy(p, x.rt);

        else if (p.x() < x.p.x()) return containsy(p, x.lb);

        else return true;
    }

    private boolean containsy(Point2D p, Node x) {
        if (x == null) return false;

        if (p.y() > x.p.y() || p.y() == x.p.y() && p.x() != x.p.x()) return containsx(p, x.rt);

        else if (p.y() < x.p.y()) return containsx(p, x.lb);

        else return true;
    }

    public void draw() { // draw all points to standard draw
        // StdDraw.setPenRadius();
        // for (Point2D p : pSet) {
        //     p.draw();
        // }
        drawV(root);
        StdDraw.show();
        // for (Point2D p : range(new RectHV(0, 0, 1, 1))) {
        //     StdOut.println(p.toString());
        //     p.draw();
        // }
    }

    private void drawV(Node x) {
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(0.01);
        x.p.draw();
        StdDraw.setPenColor(StdDraw.RED);
        StdDraw.setPenRadius();
        StdDraw.line(x.p.x(), x.rect.ymin(), x.p.x(), x.rect.ymax());
        if (x.rt != null) {
            drawH(x.rt);
        }
        if (x.lb != null) {
            drawH(x.lb);
        }
    }

    private void drawH(Node x) {
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setPenRadius(0.01);
        x.p.draw();
        StdDraw.setPenColor(StdDraw.BLUE);
        StdDraw.setPenRadius();
        StdDraw.line(x.rect.xmin(), x.p.y(), x.rect.xmax(), x.p.y());
        if (x.rt != null) {
            drawV(x.rt);
        }
        if (x.lb != null) {
            drawV(x.lb);
        }
    }

    // all points that are inside the rectangle (or on the boundary)
    public Iterable<Point2D> range(RectHV rect) {
        // double xmin = rect.xmin();
        // double xmax = rect.xmax();
        // double ymin = rect.ymin();
        // double ymax = rect.ymax();
        Queue<Point2D> queue = new Queue<>();
        if (root.rect.intersects(rect)) {
            // queue.enqueue(root.p);
            range(root, queue, rect);
            return queue;
        }
        else {
            return null;
        }
    }

    private void range(Node x, Queue<Point2D> q, RectHV rect) {
        if (x.rt != null && x.rt.rect.intersects(rect)) {
            range(x.rt, q, rect);
        }
        if (x.lb != null && x.lb.rect.intersects(rect)) {
            range(x.lb, q, rect);
        }
        if (rect.contains(x.p)) {
            q.enqueue(x.p);
        }
        // else return;
    }

    // a nearest neighbor in the set to point p; null if the set is empty
    public Point2D nearest(Point2D p) {
        if (p == null || isEmpty())
            return null;
        Point2D min = root.p;
        min = nearestx(root, min, p);
        return min;
    }

    private Point2D nearestx(Node x, Point2D min, Point2D p) {
        // if (x == null) return;
        if (p.distanceSquaredTo(x.p) < p.distanceSquaredTo(min)) {
            min = x.p;
            // return min;
        }

        if (x.rt != null && p.distanceSquaredTo(min) > x.rt.rect.distanceSquaredTo(p)
                && p.x() >= x.p.x())
            min = nearesty(x.rt, min, p);
        else if (x.lb != null && p.distanceSquaredTo(min) > x.lb.rect.distanceSquaredTo(p)
                && p.x() < x.p.x())
            min = nearesty(x.lb, min, p);
        return min;
    }

    private Point2D nearesty(Node x, Point2D min, Point2D p) {
        // if (x == null) return;
        if (p.distanceSquaredTo(x.p) < p.distanceSquaredTo(min)) {
            min = x.p;
            // return min;
        }

        if (x.rt != null && p.distanceSquaredTo(min) > x.rt.rect.distanceSquaredTo(p)
                && p.y() >= x.p.y())
            min = nearestx(x.rt, min, p);
        else if (x.lb != null && p.distanceSquaredTo(min) > x.lb.rect.distanceSquaredTo(p)
                && p.y() < x.p.y())
            min = nearestx(x.lb, min, p);
        return min;
    }

    // distance to a rectangle
    private double distToRect(RectHV rect, Point2D p) {
        double xmin = rect.xmin();
        double xmax = rect.xmax();
        double ymin = rect.ymin();
        double ymax = rect.ymax();
        double dist;
        if (rect.contains(p)) return 0;
        if ((p.x() < xmin || p.x() > xmax) && (p.y() < ymin || p.y() > ymax)) {
            if (p.x() < xmin && p.y() < ymin)
                dist = p.distanceSquaredTo(new Point2D(xmin, ymin));
            else if (p.x() < xmin && p.y() > ymax)
                dist = p.distanceSquaredTo(new Point2D(xmin, ymax));
            else if (p.x() > xmax && p.y() < ymin)
                dist = p.distanceSquaredTo(new Point2D(xmax, ymin));
            else
                dist = p.distanceSquaredTo(new Point2D(xmax, ymax));
        }
        else {
            if (p.y() > ymin && p.y() < ymax) {
                if (p.x() > xmax)
                    dist = p.x() - xmax;
                else
                    dist = xmin - p.x();
            }
            else {
                if (p.y() > ymax)
                    dist = p.y() - ymax;
                else
                    dist = ymin - p.y();
            }
            dist = dist * dist;
        }
        return dist;
    }

    public static void main(String[] args) {
        KdTree test = new KdTree();
        test.insert(new Point2D(0.7, 0.2));
        test.insert(new Point2D(0.5, 0.4));
        test.insert(new Point2D(0.2, 0.3));
        test.insert(new Point2D(0.4, 0.7));
        test.insert(new Point2D(0.9, 0.6));
        // test.insert(new Point2D(0.9, 0.6));
        // StdOut.println("test dis her " + test.distToRect(new RectHV(0.4, 0.3, 0.8, 0.6),
        //                                                  new Point2D(0.0, 0.0)));
        StdOut.println(test.size());
        // RectHV rect = new RectHV(0, 0, 1, 1);
        // RectHV rect1 = new RectHV(0.3, 0.3, 0.7, 0.7);
        // rect.draw();
        // rect1.draw();
        // test.draw();
        // StdDraw.show();
        // test.draw();
        // System.out.println(test.contains(new Point2D(0.5, 0.4)));
        System.out.println(test.nearest(new Point2D(0.298, 0.588)));
    }
}
